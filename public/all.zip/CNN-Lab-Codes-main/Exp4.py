
def crc16_ccitt(data):
    crc = 0xFFFF
    for byte in data:
        if type(byte) == str:  
            byte = ord(byte)
        crc ^= (byte << 8)
        for _ in range(8):
            if (crc & 0x8000):
                crc = (crc << 1) ^ 0x1021
            else:
                crc <<= 1
            crc &= 0xFFFF
    return crc

def to_hex_string(byte_list):
    return ' '.join(['%02X' % b for b in byte_list])

def generate_hdlc_frame(data, frame_type="U", address=0x01, control_code=None):
    FLAG = 0x7E  
    frame = []

    # 1. Address
    frame.append(address)

    # 2. Control Field
    if frame_type == "I":  # Information Frame
        NS = 0   # Send sequence number (3 bits)
        NR = 0   # Receive sequence number (3 bits)
        P = 0    # Poll/final bit (1 bit)
        control = (NS << 1) | 0          # Bit 4 is always 0 for I-frame
        control |= (NR << 5) | (P << 4)
    elif frame_type == "S":  # Supervisory Frame
        S_TYPE = 0  # RR = 0, RNR = 1, REJ = 2, SREJ = 3
        NR = 0
        P = 0
        control = 0b10000000 | (S_TYPE << 2) | (NR << 5) | (P << 4)
    elif frame_type == "U":  # Unnumbered Frame
        # Use standard control codes or allow custom
        control = control_code if control_code is not None else 0x03  # UI frame
    else:
        raise ValueError("Invalid frame_type. Use 'I', 'S', or 'U'.")

    frame.append(control)

    # 3. Data
    if type(data) == str:
        data = [ord(c) for c in data]
    frame += data

    # 4. FCS (CRC-16)
    fcs = crc16_ccitt(frame)
    fcs_low = fcs & 0xFF
    fcs_high = (fcs >> 8) & 0xFF
    frame += [fcs_low, fcs_high]

    # 5. Add Flags
    return [FLAG] + frame + [FLAG]


if __name__ == "__main__":
  
    print("Unnumbered Frame (UI):")
    u_frame = generate_hdlc_frame("Hello", frame_type="U", address=0xAA, control_code=0x03)
    print(to_hex_string(u_frame))


    print("\nInformation Frame:")
    i_frame = generate_hdlc_frame("Data", frame_type="I", address=0x01)
    print(to_hex_string(i_frame))


    print("\nSupervisory Frame (RR):")
    s_frame = generate_hdlc_frame("", frame_type="S", address=0x01)
    print(to_hex_string(s_frame))
