
import threading
import time

# Shared synchronous data line (bit-by-bit)
data_line = []
data_lock = threading.Lock()


CLOCK_TICK = 0.1  


def to_bits(byte):
    return [(byte >> i) & 1 for i in range(8)]  # LSB first

def from_bits(bits):
    value = 0
    for i in range(8):
        value |= (bits[i] << i)
    return value

def even_parity(bits):
    return sum(bits) % 2 == 0


def uart_encode(char):
    byte = ord(char)
    data_bits = to_bits(byte)
    parity_bit = 0 if even_parity(data_bits) else 1
    return [0] + data_bits + [parity_bit] + [1]  

def uart_decode(frame):
    if len(frame) != 11:
        return None, "Invalid frame length"
    if frame[0] != 0 or frame[-1] != 1:
        return None, "Start/Stop bit error"
    data_bits = frame[1:9]
    parity_bit = frame[9]
    if even_parity(data_bits) != (parity_bit == 0):
        return None, "Parity error"
    return chr(from_bits(data_bits)), None


def transmitter():
    message = "Sync!"
    for char in message:
        bits = uart_encode(char)
        for bit in bits:
            data_lock.acquire()
            data_line.append(bit)
            data_lock.release()
            time.sleep(CLOCK_TICK) 
        print("[Tx] Sent:", char)


def receiver():
    buffer = []
    char_count = 0
    while True:
        time.sleep(CLOCK_TICK) 
        data_lock.acquire()
        if data_line:
            bit = data_line.pop(0)
            buffer.append(bit)
        data_lock.release()

        if len(buffer) == 11:
            char, err = uart_decode(buffer)
            if err:
                print("[Rx] Error:", err, "Frame:", buffer)
            else:
                print("[Rx] Received:", char)
                if char == '!':
                    break
            buffer = [] 


if __name__ == "__main__":
    tx_thread = threading.Thread(target=transmitter)
    rx_thread = threading.Thread(target=receiver)

    tx_thread.start()
    rx_thread.start()

    tx_thread.join()
    rx_thread.join()

    print("Synchronous communication complete.")
