#!/usr/bin/env python
# coding: utf-8

# In[2]:


ascii_table = {}
for i in range(128):
    ascii_table[i] = ''.join([chr(i)])  

# Reverse table: character to value
char_to_ascii = {}
for code, char in ascii_table.items():
    char_to_ascii[char] = code


def my_ord(char):
    if char in char_to_ascii:
        return char_to_ascii[char]
    else:
        raise ValueError("Character not in ASCII range 0-127.")

def my_chr(ascii_value):
    if ascii_value in ascii_table:
        return ascii_table[ascii_value]
    else:
        raise ValueError("Value not in ASCII range 0-127.")

def ascii_encode(text):
    encoded = []
    for char in text:
        encoded.append(str(my_ord(char)))
    return ' '.join(encoded)

def ascii_decode(encoded_text):
    decoded = ''
    ascii_values = encoded_text.strip().split()
    for val in ascii_values:
        decoded += my_chr(int(val))
    return decoded

if __name__ == "__main__":
    message = "Hello, ASCII!"
    encoded = ascii_encode(message)
    print("Encoded:", encoded)

    decoded = ascii_decode(encoded)
    print("Decoded:", decoded)


# In[ ]:




