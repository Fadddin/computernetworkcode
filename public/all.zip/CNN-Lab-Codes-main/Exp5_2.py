def bellman_ford(vertices, edges, source):

    distance = {}
    for v in vertices:
        distance[v] = float('inf')
    distance[source] = 0

    for i in range(len(vertices) - 1):
        for u, v, w in edges:
            if distance[u] + w < distance[v]:
                distance[v] = distance[u] + w

    return distance

if __name__ == "__main__":
    # Define graph
    vertices = ['A', 'B', 'C', 'D', 'E']
    edges = [
        ('A', 'B', 4),
        ('A', 'C', 2),
        ('B', 'C', 3),
        ('B', 'D', 2),
        ('B', 'E', 3),
        ('C', 'B', 1),
        ('C', 'D', 4),
        ('D', 'E', 1),
        ('E', 'D', 1)
    ]


    src = 'A'


    result = bellman_ford(vertices, edges, src)


    print("Shortest distances from source '%s':" % src)
    for v in vertices:
        print("  %s → %s =" % (src, v), result[v])
