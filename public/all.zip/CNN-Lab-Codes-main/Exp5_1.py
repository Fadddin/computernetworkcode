def bellman_ford(vertices, edges, source):
    # Step 1: Initialize distances
    distance = {}
    for v in vertices:
        distance[v] = float('inf')
    distance[source] = 0

    # Step 2: Relax edges |V| - 1 times
    for i in range(len(vertices) - 1):
        for u, v, w in edges:
            if distance[u] + w < distance[v]:
                distance[v] = distance[u] + w

    # Step 3: (Skip negative cycle check)

    return distance

# -------------------
# Example Usage
# -------------------
if __name__ == "__main__":
    # Define graph
    vertices = ['A', 'B', 'C', 'D', 'E']
    edges = [
        ('A', 'B', 4),
        ('A', 'C', 2),
        ('B', 'C', 3),
        ('B', 'D', 2),
        ('B', 'E', 3),
        ('C', 'B', 1),
        ('C', 'D', 4),
        ('D', 'E', 1),
        ('E', 'D', 1)
    ]

    # Source vertex
    src = 'A'

    # Run Bellman-Ford
    result = bellman_ford(vertices, edges, src)

    # Print result
    print("Shortest distances from source '%s':" % src)
    for v in vertices:
        print("  %s → %s =" % (src, v), result[v])
