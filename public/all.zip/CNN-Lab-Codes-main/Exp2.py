#!/usr/bin/env python
# coding: utf-8

# In[3]:


import threading
import time

# Simulated bit-level channel
bit_channel = []
channel_lock = threading.Lock()


def to_bits(byte):
    bits = []
    for i in range(8):
        bits.append((byte >> i) & 1)  # LSB first
    return bits

def from_bits(bits):
    value = 0
    for i in range(8):
        value |= (bits[i] << i)
    return value

def even_parity(bits):
    return sum(bits) % 2 == 0

def uart_encode(char):
    byte = ord(char)
    data_bits = to_bits(byte)
    parity_bit = 0 if even_parity(data_bits) else 1
    frame = [0]  # Start bit
    frame += data_bits
    frame.append(parity_bit)
    frame.append(1)  # Stop bit
    return frame

def uart_decode(frame):
    if len(frame) != 11:
        return None, "Invalid frame length"
    if frame[0] != 0 or frame[-1] != 1:
        return None, "Invalid start/stop bits"
    
    data_bits = frame[1:9]
    parity = frame[9]
    
    if even_parity(data_bits) != (parity == 0):
        return None, "Parity error"
    
    return chr(from_bits(data_bits)), None


def transmitter():
    message = "Hi!"
    for char in message:
        bits = uart_encode(char)
        time.sleep(0.5)  # Delay between chars
        channel_lock.acquire()
        bit_channel.extend(bits)
        print("[Tx] Sent char:", char, "Bits:", bits)
        channel_lock.release()


def receiver():
    buffer = []
    while True:
        time.sleep(0.1)
        channel_lock.acquire()
        if bit_channel:
            bit = bit_channel.pop(0)
            buffer.append(bit)
            if len(buffer) == 11:
                char, err = uart_decode(buffer)
                if err:
                    print("[Rx] Error:", err, "Frame:", buffer)
                else:
                    print("[Rx] Received:", char)
                    if char == '!':
                        channel_lock.release()
                        break
                buffer = []  # Reset buffer
        channel_lock.release()


if __name__ == "__main__":
    tx = threading.Thread(target=transmitter)
    rx = threading.Thread(target=receiver)

    tx.start()
    rx.start()

    tx.join()
    rx.join()

    print("UART-style async communication complete.")


# In[ ]:




